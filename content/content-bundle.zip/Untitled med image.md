---
quickshare-date: 2023-11-10 18:56:19
quickshare-url: https://noteshare.space/note/closx5xld897601mwy39t9ibi#dAxMWdK3ZkTdkT1e0pqaoQrq1CtymA1hkD3Fk4RdTqI
aliases:
---
# Hej

Hej!

Bld nedan:

![[CleanShot 2023-11-10 at 18.02.20 - Obsidian@2x.png]]x